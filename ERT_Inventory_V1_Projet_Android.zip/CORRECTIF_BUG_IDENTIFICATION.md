# Correctif 2 - Plantage après identification de l’agent

Symptôme : écran rouge avec `framework.dart: _dependents.isEmpty` après la saisie du nom et l'appui sur Continuer.

Cause probable dans V1 : le `TextEditingController` de la boîte de dialogue était détruit immédiatement après la fermeture du dialogue ; puis l'application ouvrait un `showModalBottomSheet` alors que l'ancienne route et son champ texte étaient encore en transition.

Correction : remplacement de ces deux fenêtres successives par une vraie page `StartInspectionPage`, regroupant le nom et le mode de contrôle. Le contrôleur est maintenant géré par le cycle de vie de la page.

Cette correction est fondée sur l’analyse du code, pas encore confirmée par un test sur le Samsung.

Pour recompiler : conserver le nom d'archive `ERT_Inventory_V1_Projet_Android.zip` sur la branche main, remplacer l'ancien ZIP sur GitHub et attendre le workflow GitHub Actions existant.

Test après installation : Accueil > VSAV > Nom et prénom > Inventaire complet > Démarrer le contrôle > vérifier l'affichage des vérifications générales et des compartiments.
