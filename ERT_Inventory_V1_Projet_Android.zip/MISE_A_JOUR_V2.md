# ERT INVENTORY — V2 (prototype)

Cette mise à jour ajoute :
- Logo ERT dans l'en-tête et l'accueil.
- Icône Android extraite et recadrée du visuel fourni (casque et ERT).
- Photos fournies pour VSAV, FPT, VPSID, VRE, VIM et CCFL 1.
- Couleurs par véhicule sur les cartes d'accueil.
- Avancement automatique vers le compartiment suivant quand chaque matériel a été vérifié ou lorsqu'on sélectionne « Nothing to report ».

Le CCFM conserve temporairement une illustration générique : la photographie publique identifiée sur Wikimedia Commons n'a pas pu être importée dans le paquet. L'intégration de sa photo est prévue.

**Important** : cette version conserve un inventaire fonctionnel uniquement pour le VSAV, avec stockage local ; aucune synchronisation ni e-mail automatisé n'est activé. Le format PDF est inchangé.

## Mise à jour GitHub
Le workflow actuel de Digit13 extrait `ERT_Inventory_V1_Projet_Android.zip`. Pour éviter de modifier le workflow, envoyez l'archive de V2 **portant exactement ce nom** sur GitHub à la racine du dépôt, en remplaçant l'ancienne. Elle contient maintenant l'étape de génération de l'icône dans son workflow interne, mais comme le workflow existant dans le dépôt prime, il faut également ajouter cette étape sur GitHub pour obtenir l'icône de lanceur. Sinon les autres fonctionnalités V2 compileront normalement avec l'icône Flutter par défaut.
