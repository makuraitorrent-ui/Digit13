# ERT Inventory V3 — Mise à jour

## Inclus
- 7 véhicules activés : VSAV, FPT, VPSID, VRE, CCFM, VIM, CCFL 1 (pas de CCFL 2).
- Compartiments et listes d'équipements repris du PDF Microsoft Forms (67 pages).
- Passage au compartiment suivant et conservation des contrôles localement.
- Photos des 6 véhicules fournies, couleurs et logo de la V2 conservés.
- Catalogue VSAV modifié localement en V1/V2 récupéré dans cette mise à jour.

## Réserves
- La photo du CCFM est encore générique.
- Les contrôles spéciaux du formulaire (AdBlue VRE, cuves, dates, plombage et contrôles dédiés) nécessitent encore des écrans adaptés. Les informations de certains points figurent pour l'instant comme lignes de contrôle standard.
- En V3, les réglages administrateur du catalogue sont encore principalement adaptés au VSAV.
- Données locales : ni synchronisation multi-appareils ni mails automatiques.
- Cette version est à tester : compilation Android non réalisée depuis cet environnement.

## Compilation GitHub
Le ZIP est nommé exactement `ERT_Inventory_V1_Projet_Android.zip` pour rester compatible avec le workflow actuel. Remplacez uniquement cette archive à la racine du dépôt : cela déclenche la compilation. Aucun changement du fichier build-apk.yml n'est nécessaire si le workflow V2 compile déjà.
