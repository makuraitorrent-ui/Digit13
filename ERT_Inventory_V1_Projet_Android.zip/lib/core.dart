import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

const navy = 0xFF112239;
const lighterNavy = 0xFF1B3451;
const red = 0xFFE15256;
const green = 0xFF168A70;
const cream = 0xFFF3F6F9;

String prettyDate(String? iso) {
  if (iso == null) return '—';
  final d = DateTime.tryParse(iso);
  if (d == null) return iso;
  String p(int n) => n.toString().padLeft(2, '0');
  return '${p(d.day)}/${p(d.month)}/${d.year} • ${p(d.hour)}:${p(d.minute)}';
}

String newId() => '${DateTime.now().microsecondsSinceEpoch}_${Random.secure().nextInt(99999)}';
String? stringOrNull(Object? o) => o?.toString();

class ERTStore {
  ERTStore._();
  static final ERTStore instance = ERTStore._();
  late SharedPreferences prefs;
  late Map<String, dynamic> catalog;
  List<dynamic> history = [];
  List<dynamic> issues = [];
  Map<String, dynamic>? draft;

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    final original = jsonDecode(await rootBundle.loadString('assets/catalog.json')) as Map<String, dynamic>;
    final saved = _readMap('ert_catalog');
    catalog = original;
    // Preserve VSAV edits from V1/V2 while adopting the seven-vehicle V3 catalog.
    if (saved != null) {
      if (saved['vehicleSections'] is Map) {
        final merged = Map<String, dynamic>.from(original['vehicleSections'] as Map);
        merged.addAll(Map<String, dynamic>.from(saved['vehicleSections'] as Map));
        catalog['vehicleSections'] = merged;
      } else if (saved['sections'] is List) {
        (catalog['vehicleSections'] as Map)['VSAV'] = saved['sections'];
      }
    }
    for (final v in catalog['vehicles'] as List) { v['enabled'] = true; }
    history = _readList('ert_history');
    issues = _readList('ert_issues');
    draft = _readMap('ert_draft');
  }

  Map<String, dynamic>? _readMap(String key) {
    final raw = prefs.getString(key);
    if (raw == null) return null;
    try {
      return Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return null;
    }
  }

  List<dynamic> _readList(String key) {
    final raw = prefs.getString(key);
    if (raw == null) return [];
    try {
      return List<dynamic>.from(jsonDecode(raw) as List);
    } catch (_) {
      return [];
    }
  }

  Future<void> persistCatalog() => prefs.setString('ert_catalog', jsonEncode(catalog));
  Future<void> saveDraft() async {
    if (draft == null) {
      await prefs.remove('ert_draft');
    } else {
      await prefs.setString('ert_draft', jsonEncode(draft));
    }
  }

  Future<void> newDraft(String vehicle, String agent, String mode) async {
    draft = {
      'id': newId(),
      'vehicle': vehicle,
      'agent': agent.trim(),
      'mode': mode,
      'startedAt': DateTime.now().toIso8601String(),
      'fuel': null,
      'dashboard': null,
      'dashboardNote': '',
      'body': null,
      'bodyNote': '',
      'o2': null,
      'co': null,
      'coNote': '',
      'items': <String, dynamic>{},
    };
    await prefs.setString('ert_last_agent', agent.trim());
    await saveDraft();
  }

  String get selectedVehicle => draft?['vehicle']?.toString() ?? 'VSAV';
  List<dynamic> sectionsFor(String vehicle) => List<dynamic>.from(
      (catalog['vehicleSections'] as Map)[vehicle] as List? ?? []);
  List<dynamic> get sections => sectionsFor(selectedVehicle);
  void updateCurrentSections(List<dynamic> updated) {
    (catalog['vehicleSections'] as Map)[selectedVehicle] = updated;
  }
  List<dynamic> get vehicles => List<dynamic>.from(catalog['vehicles'] as List);

  Iterable<Map<String, dynamic>> activeItems() sync* {
    for (final s in sections) {
      final section = Map<String, dynamic>.from(s as Map);
      for (final item in section['items'] as List) {
        final i = Map<String, dynamic>.from(item as Map);
        if (i['active'] != false) yield i;
      }
    }
  }

  int get itemCount => activeItems().length;

  int reviewedItemCount([Map<String, dynamic>? d]) {
    final states = Map<String, dynamic>.from((d ?? draft)?['items'] as Map? ?? {});
    return activeItems().where((item) => states[item['id']] != null).length;
  }

  int missingChecks([Map<String, dynamic>? d]) {
    final p = d ?? draft;
    if (p == null) return 0;
    int n = 0;
    for (final k in ['fuel', 'dashboard', 'body']) {
      if (p[k] == null) n++;
    }
    if (p['dashboard'] == 'alert' && (p['dashboardNote'] as String? ?? '').trim().isEmpty) n++;
    if (p['body'] == 'alert' && (p['bodyNote'] as String? ?? '').trim().isEmpty) n++;
    if (p['mode'] == 'INVENTAIRE') {
      if (p['vehicle'] == 'VSAV' && p['o2'] == null) n++;
      if (p['vehicle'] == 'VSAV' && p['co'] == null) n++;
      if (p['vehicle'] == 'VSAV' && p['co'] == 'alert' && (p['coNote'] as String? ?? '').trim().isEmpty) n++;
      n += itemCount - reviewedItemCount(p);
    }
    return n;
  }

  List<Map<String, dynamic>> listAnomalies(Map<String, dynamic> d) {
    final out = <Map<String, dynamic>>[];
    final answers = Map<String, dynamic>.from(d['items'] as Map? ?? {});
    for (final section in sections) {
      for (final it in section['items'] as List) {
        final item = Map<String, dynamic>.from(it as Map);
        final answer = answers[item['id']];
        if (answer is Map && answer['status'] == 'anomaly') {
          out.add({
            'key': item['id'],
            'location': section['title'],
            'title': item['label'],
            'type': answer['type'] ?? 'Autre',
            'note': answer['note'] ?? '',
            'present': answer['present'],
            'expected': item['quantity'],
            'photos': List<String>.from(answer['photos'] as List? ?? []),
          });
        }
      }
    }
    if (d['dashboard'] == 'alert') {
      out.add({'key':'CTRL_DASHBOARD','location':'Vérifications','title':'Voyant / tableau de bord', 'type':'Autre','note':d['dashboardNote'] ?? '', 'photos':<String>[]});
    }
    if (d['body'] == 'alert') {
      out.add({'key':'CTRL_BODY','location':'Vérifications','title':'Carrosserie / signalisation', 'type':'Défectueux','note':d['bodyNote'] ?? '', 'photos':<String>[]});
    }
    if (d['vehicle'] == 'VSAV' && d['mode'] == 'INVENTAIRE' && d['co'] == 'alert') {
      out.add({'key':'CTRL_CO','location':'Sac PS','title':'Détecteur CO','type':'Défectueux / absent','note':d['coNote'] ?? '', 'photos':<String>[]});
    }
    return out;
  }

  Future<Map<String, dynamic>> completeDraft() async {
    if (draft == null) throw StateError('Aucun inventaire en cours.');
    final d = Map<String, dynamic>.from(draft!);
    final now = DateTime.now().toIso8601String();
    final items = listAnomalies(d);
    int newIssues = 0;
    final summarized = <Map<String, dynamic>>[];
    for (final item in items) {
      Map<String, dynamic>? known;
      for (final raw in issues) {
        final existing = Map<String, dynamic>.from(raw as Map);
        if (existing['vehicle'] == d['vehicle'] && existing['key'] == item['key'] && existing['type'] == item['type'] && existing['status'] != 'resolved') {
          known = existing;
          break;
        }
      }
      if (known == null) {
        known = {
          ...item,
          'id': newId(),
          'vehicle': d['vehicle'],
          'status': 'open',
          'createdAt': now,
          'updatedAt': now,
          'confirmations': 1,
        };
        issues.insert(0, known);
        newIssues++;
      } else {
        known['updatedAt'] = now;
        known['confirmations'] = ((known['confirmations'] as num?)?.toInt() ?? 1) + 1;
        // Conserve la dernière observation quand elle a été renseignée.
        if ((item['note'] as String).trim().isNotEmpty) known['note'] = item['note'];
        final idx = issues.indexWhere((v) => v['id'] == known!['id']);
        if (idx >= 0) issues[idx] = known;
      }
      summarized.add({...item, 'existing': known['confirmations'] != 1, 'issueId':known['id']});
    }
    d['completedAt'] = now;
    d['missingCount'] = missingChecks(d);
    d['findings'] = summarized;
    d['newIssues'] = newIssues;
    history.insert(0, d);
    await prefs.setString('ert_history', jsonEncode(history));
    await prefs.setString('ert_issues', jsonEncode(issues));
    draft = null;
    await saveDraft();
    return d;
  }

  Future<void> issueStatus(String id, String status) async {
    for (var i = 0; i < issues.length; i++) {
      if (issues[i]['id'] == id) {
        final value = Map<String, dynamic>.from(issues[i] as Map);
        value['status'] = status;
        value['updatedAt'] = DateTime.now().toIso8601String();
        issues[i] = value;
        break;
      }
    }
    await prefs.setString('ert_issues', jsonEncode(issues));
  }

  bool get adminConfigured => prefs.getString('ert_admin_hash') != null;

  Future<void> setAdminPin(String pin) async {
    final salt = newId();
    await prefs.setString('ert_admin_salt', salt);
    await prefs.setString('ert_admin_hash', sha256.convert(utf8.encode('$salt$pin')).toString());
  }

  bool verifyAdminPin(String pin) {
    final salt = prefs.getString('ert_admin_salt');
    final hash = prefs.getString('ert_admin_hash');
    if (salt == null || hash == null) return false;
    return sha256.convert(utf8.encode('$salt$pin')).toString() == hash;
  }

  Future<String> savePhoto(File temporary) async {
    final docs = await getApplicationDocumentsDirectory();
    final folder = Directory('${docs.path}/photos');
    await folder.create(recursive: true);
    final dest = File('${folder.path}/${newId()}.jpg');
    return (await temporary.copy(dest.path)).path;
  }

  Future<File> makeReport(Map<String, dynamic> check) async {
    final doc = pw.Document();
    final findings = List<dynamic>.from(check['findings'] as List? ?? []);
    final lines = <pw.Widget>[
      pw.Container(
        padding: const pw.EdgeInsets.all(14),
        color: PdfColor.fromInt(navy),
        child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Text('ERT  |  INVENTORY', style: pw.TextStyle(color: PdfColors.white, fontSize: 20, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 5),
          pw.Text('RAPPORT DE CONTRÔLE - ${check['vehicle']}', style: const pw.TextStyle(color: PdfColors.white, fontSize: 12)),
        ]),
      ),
      pw.SizedBox(height: 12),
      pw.Text('Agent : ${check['agent']}'),
      pw.Text('Date : ${prettyDate(check['completedAt']?.toString())}'),
      pw.Text('Opération : ${check['mode']}'),
      pw.Text('Points non vérifiés : ${check['missingCount'] ?? 0}'),
      pw.SizedBox(height: 8),
      pw.Text('Carburant : ${check['fuel'] ?? 'non renseigné'}  |  O2 : ${check['o2'] ?? '—'}/10'),
      pw.SizedBox(height: 15),
      pw.Text('Anomalies relevées : ${findings.length}', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 15)),
      pw.SizedBox(height: 10),
    ];
    if (findings.isEmpty) {
      lines.add(pw.Text('Aucune anomalie renseignée lors de ce contrôle.'));
    }
    for (var i = 0; i < findings.length; i++) {
      final item = Map<String, dynamic>.from(findings[i] as Map);
      lines.add(pw.Container(
        margin: const pw.EdgeInsets.only(bottom: 8),
        padding: const pw.EdgeInsets.all(9),
        decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey400), borderRadius: pw.BorderRadius.circular(4)),
        child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Text('${i + 1}. ${item['title']}', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          pw.Text('${item['location']} • ${item['type']} • ${item['existing'] == true ? 'Déjà signalée' : 'Nouvelle'}'),
          if (item['expected'] != null) pw.Text('Quantité attendue : ${item['expected']} | présente : ${item['present'] ?? 'non précisée'}'),
          if ((item['note'] ?? '').toString().trim().isNotEmpty) pw.Text('Observation : ${item['note']}'),
        ]),
      ));
      for (final path in List<String>.from(item['photos'] as List? ?? []).take(4)) {
        try {
          final file = File(path);
          if (!file.existsSync()) continue;
          lines.add(pw.Container(margin: const pw.EdgeInsets.only(bottom: 10), child: pw.Image(pw.MemoryImage(file.readAsBytesSync()), height: 150, fit: pw.BoxFit.contain)));
        } catch (_) {
          // Une image supprimée ne doit pas empêcher l'édition du rapport.
        }
      }
    }
    lines.add(pw.SizedBox(height: 12));
    lines.add(pw.Text('Prototype V1 - données enregistrées sur ce téléphone uniquement.', style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)));
    doc.addPage(pw.MultiPage(pageFormat: PdfPageFormat.a4, margin: const pw.EdgeInsets.all(32), build: (_) => lines));
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory('${docs.path}/reports');
    await dir.create(recursive: true);
    final result = File('${dir.path}/ERT_${check['vehicle']}_${check['id']}.pdf');
    await result.writeAsBytes(await doc.save());
    return result;
  }

  Future<void> shareReport(Map<String, dynamic> check) async {
    final file = await makeReport(check);
    final findings = List<dynamic>.from(check['findings'] as List? ?? []);
    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'application/pdf')],
      subject: 'ERT | ${check['vehicle']} | ${findings.length} anomalie(s)',
      text: 'Rapport ${check['mode']} du ${prettyDate(check['completedAt']?.toString())}, véhicule ${check['vehicle']}, agent ${check['agent']}.\n${findings.length} anomalie(s). Merci de consulter le PDF joint.',
    );
  }
}
