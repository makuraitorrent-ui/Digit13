import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'core.dart';

const Color darkBlue = Color(navy);
const Color midBlue = Color(lighterNavy);
const Color alertRed = Color(red);
const Color checkGreen = Color(green);
const Color pale = Color(cream);
const Map<String, String> vehiclePhotos = {
  'VSAV': 'assets/vehicles/vsav.jpg',
  'FPT': 'assets/vehicles/fpt.jpg',
  'VPSID': 'assets/vehicles/vpsid.jpg',
  'VRE': 'assets/vehicles/vre.jpg',
  'VIM': 'assets/vehicles/vim.jpg',
  'CCFL1': 'assets/vehicles/ccfl.jpg',
};
const Map<String, Color> vehicleAccents = {
  'VSAV': Color(0xFFDF4852),
  'FPT': Color(0xFFCE392F),
  'VPSID': Color(0xFF8D354A),
  'VRE': Color(0xFFD99027),
  'VIM': Color(0xFFB84A30),
  'CCFM': Color(0xFF648248),
  'CCFL1': Color(0xFFBE8B36),
};

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ERTStore.instance.init();
  runApp(const ERTApp());
}

class ERTApp extends StatelessWidget {
  const ERTApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'ERT Inventory',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: pale,
      colorScheme: ColorScheme.fromSeed(seedColor: darkBlue, primary: darkBlue, secondary: alertRed),
      appBarTheme: const AppBarTheme(backgroundColor: darkBlue, foregroundColor: Colors.white, elevation: 0),
      cardTheme: CardThemeData(color: Colors.white, elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17))),
      inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12)),
    ),
    home: const HomePage(),
  );
}

Widget badge(String label, Color color, {IconData? icon}) => Container(
  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
  decoration: BoxDecoration(color: color.withValues(alpha: .10), borderRadius: BorderRadius.circular(40)),
  child: Row(mainAxisSize: MainAxisSize.min, children: [
    if (icon != null) ...[Icon(icon, size: 14, color: color), const SizedBox(width: 4)],
    Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 11)),
  ]),
);

Widget padCard({required Widget child, EdgeInsetsGeometry padding = const EdgeInsets.all(16)}) => Card(child: Padding(padding: padding, child: child));

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final store = ERTStore.instance;

  Future<void> beginVehicle(String vehicle) async {
    if (store.draft != null) {
      final continueDraft = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Contrôle en cours'),
          content: Text('Un contrôle ${store.draft!['mode']} de ${store.draft!['vehicle']} a été commencé par ${store.draft!['agent']}. Le reprendre ?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Nouveau contrôle')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Reprendre')),
          ],
        ),
      );
      if (!mounted || continueDraft == null) return;
      if (continueDraft) {
        await Navigator.push(context, MaterialPageRoute(builder: (_) => const InspectionPage()));
        if (mounted) setState(() {});
        return;
      }
    }
    // Le choix du nom et du type de contrôle se fait sur une vraie page.
    // Évite de fermer une boîte de dialogue puis d'ouvrir un bottom-sheet
    // pendant que les widgets liés au champ texte sont encore en transition.
    await Navigator.push<void>(
      context,
      MaterialPageRoute(builder: (_) => StartInspectionPage(vehicle: vehicle)),
    );
    if (mounted) setState(() {});
  }

  Future<void> scan() async {
    final value = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => const ScannerPage()));
    if (value != null && mounted) await beginVehicle(value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Row(children: [ClipRRect(borderRadius: BorderRadius.circular(6), child: Image.asset('assets/branding/app_icon.png', height: 35, width: 35, fit: BoxFit.cover)), const SizedBox(width: 9), const Text('ERT  INVENTORY', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.0, fontSize: 18))]),
        actions: [IconButton(onPressed: scan, tooltip: 'Scanner QR code', icon: const Icon(Icons.qr_code_scanner))]),
      body: IndexedStack(index: tab, children: [
        _dashboard(),
        IssuesPage(refreshParent: () => setState(() {})),
        HistoryPage(refreshParent: () => setState(() {})),
        const AdminGatePage(),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.local_shipping_outlined), selectedIcon: Icon(Icons.local_shipping), label: 'Véhicules'),
          NavigationDestination(icon: Icon(Icons.report_problem_outlined), selectedIcon: Icon(Icons.report_problem), label: 'Anomalies'),
          NavigationDestination(icon: Icon(Icons.history_outlined), selectedIcon: Icon(Icons.history), label: 'Historique'),
          NavigationDestination(icon: Icon(Icons.admin_panel_settings_outlined), selectedIcon: Icon(Icons.admin_panel_settings), label: 'Admin'),
        ],
      ),
    );
  }

  Widget _dashboard() {
    final openCount = store.issues.where((e) => e['status'] != 'resolved').length;
    final doneCount = store.history.length;
    return ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 25), children: [
      Container(
        padding: const EdgeInsets.all(21),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [darkBlue, midBlue]), borderRadius: BorderRadius.circular(20)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.asset('assets/branding/ert_logo.jpg', height: 75, width: 75, fit: BoxFit.cover)),
            const SizedBox(width: 13),
            const Expanded(child: Text('CONTRÔLE DU PARC\nE.R.T.', style: TextStyle(color: Color(0xFFBBD3E6), letterSpacing: 1.2, fontSize: 14, fontWeight: FontWeight.w800))),
          ]),
          const SizedBox(height: 7),
          const Text('Prêts à intervenir.', style: TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.bold)),
          const SizedBox(height: 7),
          const Text('Inventaires rapides, anomalies précises.', style: TextStyle(color: Color(0xFFCEDCE8), fontSize: 13)),
          const SizedBox(height: 20),
          Row(children: [
            Expanded(child: _topMetric('7', 'véhicules', Icons.local_shipping_outlined)),
            const SizedBox(width: 8),
            Expanded(child: _topMetric('$doneCount', 'contrôles enregistrés', Icons.fact_check_outlined)),
            const SizedBox(width: 8),
            Expanded(child: _topMetric('$openCount', 'anomalies', Icons.warning_amber_rounded)),
          ]),
        ]),
      ),
      if (store.draft != null) ...[
        const SizedBox(height: 14),
        padCard(child: ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.restore, color: Colors.orange),
          title: Text('Contrôle à reprendre • ${store.draft!['vehicle']}'),
          subtitle: Text('${store.draft!['agent']} • ${store.draft!['mode']}'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => beginVehicle(store.draft!['vehicle'].toString()),
        )),
      ],
      const SizedBox(height: 24),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('Choisir un véhicule', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: darkBlue)),
        InkWell(onTap: scan, child: const Icon(Icons.qr_code_2, size: 27, color: darkBlue)),
      ]),
      const SizedBox(height: 12),
      ...store.vehicles.map((v) {
        final id = v['id'].toString();
        final ready = v['enabled'] == true;
        final count = store.issues.where((e) => e['vehicle'] == id && e['status'] != 'resolved').length;
        final accent = vehicleAccents[id] ?? darkBlue;
        final photo = vehiclePhotos[id];
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Card(clipBehavior: Clip.antiAlias, child: InkWell(
            onTap: () => beginVehicle(id),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SizedBox(height: 110, width: double.infinity, child: Stack(fit: StackFit.expand, children: [
                if (photo != null) Image.asset(photo, fit: BoxFit.cover, alignment: Alignment.center)
                else Container(color: const Color(0xFFE0E6EA), child: const Center(child: Icon(Icons.fire_truck_outlined, size: 50, color: darkBlue))),
                Align(alignment: Alignment.bottomCenter, child: Container(height: 37, decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black.withValues(alpha: .48)])))),
                Positioned(left: 12, bottom: 8, child: Text(id == 'CCFL1' ? 'CCFL 1' : id, style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900, shadows: [Shadow(color: Colors.black54, blurRadius: 6)]))),
              ])),
              Container(height: 4, color: accent),
              Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11), child: Row(children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(v['subtitle']?.toString() ?? id, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: darkBlue, fontWeight: FontWeight.w700)),
                  Text(ready ? 'Contrôle disponible' : 'Inventaire en préparation', style: const TextStyle(color: Colors.blueGrey, fontSize: 11)),
                ])),
                if (ready && count > 0) badge('$count alerte(s)', alertRed, icon: Icons.warning_amber_rounded)
                else if (ready) badge('Prêt', checkGreen, icon: Icons.check_circle_outline)
                else badge('À venir', Colors.blueGrey),
                const Icon(Icons.chevron_right, color: Colors.blueGrey),
              ])),
            ]),
          )),
        );
      }),
      const SizedBox(height: 10),
      const Text('PROTOTYPE V3 • Données enregistrées sur ce téléphone. Synchronisation et e-mails automatiques non activés.', style: TextStyle(fontSize: 11, color: Colors.blueGrey)),
    ]);
  }

  Widget _topMetric(String value, String label, IconData icon) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .09), borderRadius: BorderRadius.circular(12)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: const Color(0xFFFF8587), size: 20),
      const SizedBox(height: 8),
      Text(value, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
      Text(label, style: const TextStyle(color: Color(0xFFE0E7EE), fontSize: 10)),
    ]),
  );
}

/// Préparation d'un contrôle sur une page dédiée. Le contrôleur du champ
/// est conservé jusqu'au démontage effectif de la page Flutter.
class StartInspectionPage extends StatefulWidget {
  final String vehicle;
  const StartInspectionPage({required this.vehicle, super.key});

  @override
  State<StartInspectionPage> createState() => _StartInspectionPageState();
}

class _StartInspectionPageState extends State<StartInspectionPage> {
  late final TextEditingController agentController;
  String mode = 'INVENTAIRE';
  bool submitting = false;

  @override
  void initState() {
    super.initState();
    agentController = TextEditingController(
      text: ERTStore.instance.prefs.getString('ert_last_agent') ?? '',
    );
    agentController.addListener(_refresh);
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    agentController.removeListener(_refresh);
    agentController.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    final name = agentController.text.trim();
    if (name.length < 3 || submitting) return;
    FocusScope.of(context).unfocus();
    setState(() => submitting = true);
    try {
      await ERTStore.instance.newDraft(widget.vehicle, name, mode);
      if (!mounted) return;
      // La page est remplacée par l'inventaire : ni dialogue, ni bottom-sheet.
      Navigator.of(context).pushReplacement<void, void>(
        MaterialPageRoute(builder: (_) => const InspectionPage()),
      );
    } catch (error) {
      if (!mounted) return;
      setState(() => submitting = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Impossible de démarrer le contrôle : $error')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final validName = agentController.text.trim().length >= 3;
    return Scaffold(
      appBar: AppBar(title: Text('Nouveau contrôle • ${widget.vehicle}')),
      body: SafeArea(child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 8),
          const Icon(Icons.local_fire_department_rounded, size: 45, color: alertRed),
          const SizedBox(height: 14),
          const Text('Qui effectue le contrôle ?',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: darkBlue)),
          const SizedBox(height: 10),
          const Text('Renseignez le nom et le prénom de l’agent.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.blueGrey)),
          const SizedBox(height: 24),
          TextField(
            controller: agentController,
            autofocus: false,
            textCapitalization: TextCapitalization.words,
            textInputAction: TextInputAction.done,
            decoration: const InputDecoration(
              labelText: 'Nom et prénom',
              prefixIcon: Icon(Icons.person_outline),
            ),
            onSubmitted: (_) { if (validName) FocusScope.of(context).unfocus(); },
          ),
          const SizedBox(height: 25),
          const Text('Type de contrôle',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: darkBlue)),
          const SizedBox(height: 10),
          Card(child: Column(children: [
            RadioListTile<String>(
              title: const Text('Inventaire complet'),
              subtitle: const Text('Vérifications + compartiments du véhicule'),
              value: 'INVENTAIRE',
              groupValue: mode,
              onChanged: submitting ? null : (v) => setState(() => mode = v!),
            ),
            const Divider(height: 1),
            RadioListTile<String>(
              title: const Text('Vérification'),
              subtitle: const Text('Voyants, carburant et carrosserie'),
              value: 'VERIFICATION',
              groupValue: mode,
              onChanged: submitting ? null : (v) => setState(() => mode = v!),
            ),
          ])),
          const SizedBox(height: 25),
          SizedBox(height: 54, child: FilledButton.icon(
            onPressed: validName && !submitting ? _start : null,
            icon: submitting
              ? const SizedBox(width: 17, height: 17,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Icon(Icons.arrow_forward_rounded),
            label: const Text('DÉMARRER LE CONTRÔLE'),
          )),
        ],
      )),
    );
  }
}

class InspectionPage extends StatefulWidget {
  const InspectionPage({super.key});
  @override
  State<InspectionPage> createState() => _InspectionPageState();
}

class _InspectionPageState extends State<InspectionPage> {
  final store = ERTStore.instance;
  Map<String, dynamic> get d => store.draft!;
  final Map<String, ExpansibleController> sectionControllers = {};
  final ScrollController inventoryScroll = ScrollController();
  String activeSectionId = ''; 

  @override
  void dispose() {
    for (final c in sectionControllers.values) { c.dispose(); }
    inventoryScroll.dispose();
    super.dispose();
  }

  void advanceIfSectionComplete() {
    final sections = store.sections.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    if (activeSectionId.isEmpty && sections.isNotEmpty) activeSectionId = sections.first['id'].toString();
    final currentIndex = sections.indexWhere((s) => s['id'] == activeSectionId);
    if (currentIndex < 0 || currentIndex >= sections.length - 1) return;
    final currentItems = (sections[currentIndex]['items'] as List).where((e) => e['active'] != false).toList();
    final states = itemMap();
    if (currentItems.isEmpty || currentItems.any((e) => states[e['id']] == null)) return;
    final next = sections[currentIndex + 1]['id'].toString();
    sectionControllers[activeSectionId]?.collapse();
    activeSectionId = next;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      sectionControllers[next]?.expand();
      // La fermeture de la section precedente amène naturellement la suivante à l'écran.
    });
  }

  void setValue(String key, dynamic value) {
    setState(() => d[key] = value);
    store.saveDraft();
  }

  Map<String, dynamic> itemMap() => Map<String, dynamic>.from(d['items'] as Map? ?? {});

  void markConform(String itemId) {
    final states = itemMap();
    states[itemId] = {'status':'ok'};
    setValue('items', states);
    advanceIfSectionComplete();
  }

  Future<void> setWholeSection(Map<String, dynamic> section) async {
    final items = List<dynamic>.from(section['items'] as List).where((x) => x['active'] != false).toList();
    final states = itemMap();
    final anomalies = items.any((e) => states[e['id']]?['status'] == 'anomaly');
    final knownOpen = items.any((it) => store.issues.any((issue) => issue['vehicle'] == d['vehicle'] && issue['key'] == it['id'] && issue['status'] != 'resolved'));
    if (anomalies || knownOpen) {
      final confirm = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
        title: Text(anomalies ? 'Écraser les anomalies ?' : 'Anomalie antérieure ouverte'),
        content: Text(anomalies ? 'Cette action marquera aussi comme conformes les équipements précédemment signalés en anomalie dans CE contrôle.' : 'Ce compartiment possède une anomalie antérieure non clôturée. La validation du compartiment ne résoudra pas cette anomalie ; un administrateur devra la traiter.'),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Tout conforme'))],
      ));
      if (confirm != true || !mounted) return;
    }
    for (final item in items) { states[item['id']] = {'status':'ok'}; }
    setValue('items', states);
    advanceIfSectionComplete();
  }

  Future<void> editItem(Map<String, dynamic> item) async {
    final old = itemMap()[item['id']];
    final answer = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => AnomalyEditor(item: item, existing: old is Map ? Map<String, dynamic>.from(old) : null),
    );
    if (answer == null || !mounted) return;
    final states = itemMap();
    states[item['id']] = answer;
    setValue('items', states);
    advanceIfSectionComplete();
  }

  Future<void> finish() async {
    final missing = store.missingChecks();
    if (missing > 0) {
      final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
        title: Text('$missing point(s) non vérifié(s)'),
        content: const Text('Le rapport sera signalé comme PARTIEL. Il ne faudra pas interpréter les éléments non contrôlés comme conformes.'),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Poursuivre')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Terminer partiellement'))],
      ));
      if (ok != true || !mounted) return;
    } else {
      final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('Valider le contrôle ?'),
        content: const Text('Le contrôle sera archivé localement avec les anomalies relevées.'),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Valider'))],
      ));
      if (ok != true || !mounted) return;
    }
    final completed = await store.completeDraft();
    if (!mounted) return;
    await Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => CompletedPage(record: completed)));
  }

  @override
  Widget build(BuildContext context) {
    final isInventory = d['mode'] == 'INVENTAIRE';
    final reviewed = store.reviewedItemCount();
    final total = store.itemCount;
    return Scaffold(
      appBar: AppBar(title: Text('${d['vehicle']} • ${isInventory ? 'Inventaire' : 'Vérification'}'), actions: [IconButton(onPressed: () => Navigator.pop(context), tooltip: 'Enregistrer et quitter', icon: const Icon(Icons.save_outlined))]),
      body: Column(children: [
        Container(color: darkBlue, width: double.infinity, padding: const EdgeInsets.fromLTRB(18, 0, 18, 16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Agent : ${d['agent']}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(height: 8),
          if (isInventory) ...[
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('Progression du matériel', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              Text('$reviewed / $total', style: const TextStyle(color: Colors.white)),
            ]),
            const SizedBox(height: 7),
            LinearProgressIndicator(value: total == 0 ? 1 : reviewed / total, backgroundColor: Colors.white24, color: const Color(0xFF49C6A5), minHeight: 7, borderRadius: BorderRadius.circular(8)),
          ] else const Text('Vérifications générales', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        ])),
        Expanded(child: ListView(controller: inventoryScroll, padding: const EdgeInsets.fromLTRB(14, 14, 14, 24), children: [
          _controlCard(),
          if (isInventory) ...[
            const SizedBox(height: 21),
            const Padding(padding: EdgeInsets.symmetric(horizontal: 4), child: Text('INVENTAIRE PAR COMPARTIMENT', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Colors.blueGrey, letterSpacing: 1))),
            const SizedBox(height: 9),
            ...store.sections.map((e) => _sectionCard(Map<String, dynamic>.from(e as Map))),
          ],
          const SizedBox(height: 14),
          const Padding(padding: EdgeInsets.all(8), child: Text('Une ligne non contrôlée reste « À vérifier ». Les anomalies sont enregistrées seulement après validation du contrôle.', textAlign: TextAlign.center, style: TextStyle(color: Colors.blueGrey, fontSize: 11))),
        ])),
        SafeArea(top: false, child: Container(padding: const EdgeInsets.fromLTRB(16, 10, 16, 12), color: Colors.white, child: SizedBox(width: double.infinity, height: 49,
          child: FilledButton.icon(onPressed: finish, icon: const Icon(Icons.done_all), label: const Text('TERMINER LE CONTRÔLE'), style: FilledButton.styleFrom(backgroundColor: darkBlue, foregroundColor: Colors.white)),
        ))),
      ]),
    );
  }

  Widget _controlCard() => padCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Row(children: [Icon(Icons.fact_check_outlined, color: darkBlue), SizedBox(width: 8), Text('Vérifications générales', style: TextStyle(color: darkBlue, fontSize: 19, fontWeight: FontWeight.bold))]),
    const SizedBox(height: 17),
    const Text('Niveau de carburant', style: TextStyle(fontWeight: FontWeight.w700)),
    const SizedBox(height: 8),
    Wrap(spacing: 8, children: ['1/4','2/4','3/4','4/4'].map((v) => ChoiceChip(label: Text(v), selected: d['fuel'] == v, onSelected: (_) => setValue('fuel', v))).toList()),
    const Divider(height: 28),
    const Text('Voyant ou information au tableau de bord ?', style: TextStyle(fontWeight: FontWeight.w700)),
    const SizedBox(height: 7),
    Wrap(spacing: 9, children: [
      ChoiceChip(label: const Text('Aucun voyant'), selected: d['dashboard'] == 'ok', onSelected: (_) => setValue('dashboard', 'ok')),
      ChoiceChip(label: const Text('Voyant présent'), selected: d['dashboard'] == 'alert', onSelected: (_) => setValue('dashboard', 'alert')),
    ]),
    if (d['dashboard'] == 'alert') ...[const SizedBox(height: 9), TextFormField(initialValue: d['dashboardNote'] as String? ?? '', decoration: const InputDecoration(labelText:'Quel(s) voyant(s) ? *'), maxLines: 2, onChanged: (v) {d['dashboardNote'] = v; store.saveDraft();})],
    const Divider(height: 28),
    const Text('État de la carrosserie / signalisation', style: TextStyle(fontWeight: FontWeight.w700)),
    const SizedBox(height: 7),
    Wrap(spacing: 9, children: [
      ChoiceChip(label: const Text('Conforme'), selected: d['body'] == 'ok', onSelected: (_) => setValue('body', 'ok')),
      ChoiceChip(label: const Text('Anomalie'), selected: d['body'] == 'alert', onSelected: (_) => setValue('body', 'alert')),
    ]),
    if (d['body'] == 'alert') ...[const SizedBox(height: 9), TextFormField(initialValue: d['bodyNote'] as String? ?? '', decoration: const InputDecoration(labelText:'Préciser le défaut *'), maxLines: 2, onChanged: (v) {d['bodyNote'] = v; store.saveDraft();})],
    if (d['mode'] == 'INVENTAIRE' && d['vehicle'] == 'VSAV') ...[
      const Divider(height: 28),
      const Text('Sac PS • Bouteille O₂ B5 (0 à 10)', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 7),
      Text(d['o2'] == null ? 'Niveau non renseigné' : '${d['o2']} / 10', style: const TextStyle(color: darkBlue)),
      Slider(min: 0, max: 10, divisions: 10, value: ((d['o2'] as num?)?.toDouble() ?? 0), onChanged: (v) => setValue('o2', v.round())),
      const Divider(height: 28),
      const Text('Détecteur CO • présent et fonctionnel ?', style: TextStyle(fontWeight: FontWeight.w700)),
      const Text('Prochaine échéance indiquée dans le formulaire : novembre 2026.', style: TextStyle(color: Colors.blueGrey, fontSize: 11)),
      const SizedBox(height: 7),
      Wrap(spacing: 9, children: [
        ChoiceChip(label: const Text('Oui'), selected: d['co'] == 'ok', onSelected: (_) => setValue('co', 'ok')),
        ChoiceChip(label: const Text('Non'), selected: d['co'] == 'alert', onSelected: (_) => setValue('co', 'alert')),
      ]),
      if (d['co'] == 'alert') ...[const SizedBox(height: 9), TextFormField(initialValue: d['coNote'] as String? ?? '', decoration: const InputDecoration(labelText:'Absent ou autre problème ? *'), maxLines: 2, onChanged: (v) {d['coNote'] = v; store.saveDraft();})],
    ],
  ]));

  Widget _sectionCard(Map<String, dynamic> section) {
    final items = List<dynamic>.from(section['items'] as List).where((it) => it['active'] != false).toList();
    if (items.isEmpty) return const SizedBox.shrink();
    final states = itemMap();
    final done = items.where((it) => states[it['id']] != null).length;
    final bad = items.where((it) => states[it['id']]?['status'] == 'anomaly').length;
    return Padding(padding: const EdgeInsets.only(bottom: 10), child: Card(child: ExpansionTile(
      controller: sectionControllers.putIfAbsent(section['id'].toString(), () => ExpansibleController()),
      onExpansionChanged: (expanded) { if (expanded) activeSectionId = section['id'].toString(); },
      initiallyExpanded: section['id'] == store.sections.first['id'],
      shape: const Border(),
      leading: CircleAvatar(backgroundColor: bad > 0 ? const Color(0xFFFFECEC) : const Color(0xFFEAF1F7), child: Icon(bad > 0 ? Icons.warning_amber_rounded : Icons.inventory_2_outlined, color: bad > 0 ? alertRed : darkBlue, size: 21)),
      title: Text(section['title'].toString(), style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: darkBlue)),
      subtitle: Text('$done / ${items.length} vérifiés${bad > 0 ? ' • $bad anomalie(s)' : ''}', style: TextStyle(fontSize: 12, color: bad > 0 ? alertRed : Colors.blueGrey)),
      children: [
        Padding(padding: const EdgeInsets.symmetric(horizontal: 15), child: Align(alignment: Alignment.centerRight, child: OutlinedButton.icon(onPressed: () => setWholeSection(section), icon: const Icon(Icons.done_all, size: 17), label: const Text('Nothing to report')))),
        const SizedBox(height: 3),
        for (final raw in items) _itemRow(Map<String, dynamic>.from(raw as Map), states),
        const SizedBox(height: 9),
      ],
    )));
  }

  Widget _itemRow(Map<String, dynamic> item, Map<String, dynamic> states) {
    final result = states[item['id']];
    final status = result is Map ? result['status'] : null;
    final isBad = status == 'anomaly';
    final isOk = status == 'ok';
    final knownOpen = store.issues.where((e) => e['vehicle'] == d['vehicle'] && e['key'] == item['id'] && e['status'] != 'resolved').toList();
    return Column(children: [
      const Divider(height: 1, indent: 16, endIndent: 16),
      Padding(padding: const EdgeInsets.fromLTRB(12, 7, 8, 7), child: Row(children: [
        Expanded(child: InkWell(onTap: () => editItem(item), child: Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(item['label'].toString(), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          if (knownOpen.isNotEmpty) const Text('⚠ Anomalie antérieure toujours ouverte', style: TextStyle(color: alertRed, fontSize: 11, fontWeight: FontWeight.w700)),
          if (isBad) Text('${result['type']}${(result['note'] ?? '').toString().trim().isNotEmpty ? ' • ${result['note']}' : ''}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: alertRed, fontSize: 11))
          else if (!isOk) const Text('À vérifier', style: TextStyle(color: Colors.blueGrey, fontSize: 11)),
        ])))),
        IconButton(onPressed: () => markConform(item['id'].toString()), tooltip:'Conforme', icon: Icon(isOk ? Icons.check_circle : Icons.check_circle_outline, color: isOk ? checkGreen : Colors.grey.shade400)),
        IconButton(onPressed: () => editItem(item), tooltip: 'Signaler une anomalie', icon: Icon(isBad ? Icons.report_problem : Icons.report_problem_outlined, color: isBad ? alertRed : Colors.grey.shade500)),
      ])),
    ]);
  }
}

class AnomalyEditor extends StatefulWidget {
  final Map<String, dynamic> item;
  final Map<String, dynamic>? existing;
  const AnomalyEditor({required this.item, required this.existing, super.key});
  @override
  State<AnomalyEditor> createState() => _AnomalyEditorState();
}

class _AnomalyEditorState extends State<AnomalyEditor> {
  late String type;
  late TextEditingController noteController;
  late TextEditingController qtyController;
  late List<String> photos;
  bool waiting = false;

  @override
  void initState() {
    super.initState();
    final ex = widget.existing ?? {};
    type = ['Manquant','Défectueux','Périmé','Autre'].contains(ex['type']) ? ex['type'].toString() : 'Manquant';
    noteController = TextEditingController(text: ex['note']?.toString() ?? '');
    qtyController = TextEditingController(text: ex['present']?.toString() ?? '');
    photos = List<String>.from(ex['photos'] as List? ?? []);
  }

  @override
  void dispose() { noteController.dispose(); qtyController.dispose(); super.dispose(); }

  Future<void> addPhoto(ImageSource source) async {
    try {
      final shot = await ImagePicker().pickImage(source: source, imageQuality: 65, maxWidth: 1600);
      if (shot == null) return;
      setState(() => waiting = true);
      final path = await ERTStore.instance.savePhoto(File(shot.path));
      if (mounted) setState(() {photos.add(path); waiting = false;});
    } catch (e) {
      if (mounted) {setState(() => waiting = false); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Photo impossible : $e')));}
    }
  }

  void submit() {
    final qty = qtyController.text.trim().isEmpty ? null : int.tryParse(qtyController.text.trim());
    if (qtyController.text.trim().isNotEmpty && (qty == null || qty < 0)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('La quantité présente doit être un nombre positif ou zéro.')));
      return;
    }
    if (noteController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ajoute une observation précise sur cette anomalie.')));
      return;
    }
    Navigator.pop(context, {'status':'anomaly','type':type,'note':noteController.text.trim(),'present':qty,'photos':photos});
  }

  @override
  Widget build(BuildContext context) => SafeArea(child: Padding(
    padding: EdgeInsets.fromLTRB(20, 0, 20, MediaQuery.of(context).viewInsets.bottom + 18),
    child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
      const Text('SIGNALER UNE ANOMALIE', style: TextStyle(color: alertRed, fontSize: 12, letterSpacing: 1.0, fontWeight: FontWeight.w800)),
      const SizedBox(height: 6),
      Text(widget.item['label'].toString(), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: darkBlue)),
      const SizedBox(height: 15),
      const Text('Type de problème', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 7),
      Wrap(spacing: 8, runSpacing: 2, children: ['Manquant','Défectueux','Périmé','Autre'].map((t) => ChoiceChip(label: Text(t), selected: type == t, onSelected: (_) => setState(() => type = t))).toList()),
      const SizedBox(height: 15),
      TextField(controller: qtyController, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Quantité présente (facultatif)', helperText: widget.item['quantity'] == null ? 'Quantité attendue non précisée dans la source' : 'Quantité attendue : ${widget.item['quantity']}')),
      const SizedBox(height: 12),
      TextField(controller: noteController, maxLines: 3, decoration: const InputDecoration(labelText: 'Observation détaillée *', hintText: 'Que manque-t-il ? Qu’est-ce qui ne fonctionne pas ?')),
      const SizedBox(height: 12),
      const Text('Photographies', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      Row(children: [
        OutlinedButton.icon(onPressed: waiting ? null : () => addPhoto(ImageSource.camera), icon: const Icon(Icons.camera_alt_outlined), label: const Text('Photo')),
        const SizedBox(width: 8),
        OutlinedButton.icon(onPressed: waiting ? null : () => addPhoto(ImageSource.gallery), icon: const Icon(Icons.photo_library_outlined), label: const Text('Galerie')),
      ]),
      if (waiting) const LinearProgressIndicator(),
      if (photos.isNotEmpty) ...[
        const SizedBox(height: 8),
        SizedBox(height: 78, child: ListView(scrollDirection: Axis.horizontal, children: [for (final p in photos) Padding(padding: const EdgeInsets.only(right: 8), child: Stack(children: [
          ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.file(File(p), width: 80, height: 75, fit: BoxFit.cover)),
          Positioned(right: 0, top: 0, child: InkWell(onTap: () => setState(() => photos.remove(p)), child: const CircleAvatar(radius: 11, backgroundColor: alertRed, child: Icon(Icons.close, size: 13, color: Colors.white)))),
        ]))])),
      ],
      const SizedBox(height: 18),
      SizedBox(width: double.infinity, height: 48, child: FilledButton.icon(onPressed: submit, style: FilledButton.styleFrom(backgroundColor: alertRed), icon: const Icon(Icons.save), label: const Text('ENREGISTRER L’ANOMALIE'))),
      const SizedBox(height: 5),
      Center(child: TextButton.icon(onPressed: () => Navigator.pop(context, {'status':'ok'}), icon: const Icon(Icons.check_circle_outline, color: checkGreen), label: const Text('Finalement conforme'))),
    ])),
  ));
}

class CompletedPage extends StatelessWidget {
  final Map<String, dynamic> record;
  const CompletedPage({required this.record, super.key});
  @override
  Widget build(BuildContext context) {
    final count = (record['findings'] as List).length;
    final partial = (record['missingCount'] as int? ?? 0) > 0;
    return Scaffold(appBar: AppBar(title: const Text('Contrôle enregistré'), automaticallyImplyLeading: false), body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(20), child: Column(children: [
      CircleAvatar(radius: 41, backgroundColor: count > 0 ? const Color(0xFFFFE7E8) : const Color(0xFFDFF7EE), child: Icon(count > 0 ? Icons.warning_amber_rounded : Icons.check_circle, size: 44, color: count > 0 ? alertRed : checkGreen)),
      const SizedBox(height: 18),
      Text(partial ? 'Contrôle partiel enregistré' : 'Contrôle terminé', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: darkBlue)),
      const SizedBox(height: 6),
      Text('${record['vehicle']} • ${record['agent']}', style: const TextStyle(color: Colors.blueGrey)),
      const SizedBox(height: 25),
      padCard(child: Column(children: [
        _statRow('Anomalies relevées', '$count', count > 0 ? alertRed : checkGreen),
        const Divider(),
        _statRow('Nouvelles anomalies', '${record['newIssues']}', darkBlue),
        const Divider(),
        _statRow('Points non vérifiés', '${record['missingCount']}', partial ? alertRed : checkGreen),
      ])),
      const SizedBox(height: 17),
      if (count > 0) ...[
        SizedBox(width: double.infinity, height: 50, child: FilledButton.icon(onPressed: () async {
          try { await ERTStore.instance.shareReport(record); }
          catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Partage impossible : $e'))); }
        }, icon: const Icon(Icons.picture_as_pdf), label: const Text('PARTAGER LE RAPPORT PDF'), style: FilledButton.styleFrom(backgroundColor: alertRed))),
        const SizedBox(height: 10),
        const Text('Choisir Outlook dans la fenêtre de partage. Le partage n’équivaut pas à une confirmation d’envoi.', style: TextStyle(color: Colors.blueGrey, fontSize: 11), textAlign: TextAlign.center),
      ] else const Text('Aucune anomalie : aucun e-mail n’est nécessaire.', style: TextStyle(color: checkGreen, fontWeight: FontWeight.w700)),
      const SizedBox(height: 25),
      OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('RETOUR AUX VÉHICULES')),
    ]))));
  }
  Widget _statRow(String name, String value, Color color) => Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(name), Text(value, style: TextStyle(color: color, fontSize: 20, fontWeight: FontWeight.w800))]);
}

class IssuesPage extends StatefulWidget {
  final VoidCallback refreshParent;
  const IssuesPage({required this.refreshParent, super.key});
  @override
  State<IssuesPage> createState() => _IssuesPageState();
}

class _IssuesPageState extends State<IssuesPage> {
  bool includeResolved = false;
  @override
  Widget build(BuildContext context) {
    final items = ERTStore.instance.issues.where((e) => includeResolved || e['status'] != 'resolved').toList();
    return ListView(padding: const EdgeInsets.all(17), children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Suivi des anomalies', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: darkBlue)),
        FilterChip(label: const Text('Résolues'), selected: includeResolved, onSelected: (v) => setState(() => includeResolved = v))]),
      const SizedBox(height: 11),
      if (items.isEmpty) padCard(child: const Padding(padding: EdgeInsets.symmetric(vertical: 35), child: Column(children: [Icon(Icons.verified_outlined, size: 48, color: checkGreen), SizedBox(height: 12), Text('Aucune anomalie à afficher')]))),
      for (final raw in items) ...[
        padCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [badge(raw['vehicle'].toString(), darkBlue), const SizedBox(width: 8), badge(raw['status'] == 'resolved' ? 'Résolue' : raw['status'] == 'in_progress' ? 'En cours' : 'Ouverte', raw['status'] == 'resolved' ? checkGreen : alertRed)]),
          const SizedBox(height: 10),
          Text(raw['title'].toString(), style: const TextStyle(fontSize: 16, color: darkBlue, fontWeight: FontWeight.w800)),
          const SizedBox(height: 5),
          Text('${raw['location']} • ${raw['type']}', style: const TextStyle(fontSize: 12, color: Colors.blueGrey)),
          const SizedBox(height: 7),
          Text(raw['note']?.toString() ?? '', style: const TextStyle(fontSize: 13)),
          const SizedBox(height: 8),
          Text('Depuis le ${prettyDate(raw['createdAt']?.toString())} • ${raw['confirmations']} constat(s)', style: const TextStyle(fontSize: 11, color: Colors.blueGrey)),
        ])),
        const SizedBox(height: 9),
      ],
      const SizedBox(height: 15),
      const Text('Le statut des anomalies peut être modifié uniquement depuis le panneau administrateur.', style: TextStyle(color: Colors.blueGrey, fontSize: 12)),
    ]);
  }
}

class HistoryPage extends StatefulWidget {
  final VoidCallback refreshParent;
  const HistoryPage({required this.refreshParent, super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}
class _HistoryPageState extends State<HistoryPage> {
  @override
  Widget build(BuildContext context) {
    final items = ERTStore.instance.history;
    return ListView(padding: const EdgeInsets.all(17), children: [
      const Text('Historique des contrôles', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: darkBlue)),
      const SizedBox(height: 12),
      if (items.isEmpty) padCard(child: const Padding(padding: EdgeInsets.symmetric(vertical: 35), child: Center(child: Text('Aucun contrôle enregistré pour le moment.')))),
      for (final raw in items) Padding(padding: const EdgeInsets.only(bottom: 10), child: padCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [badge(raw['vehicle'].toString(), darkBlue), const SizedBox(width: 8), badge(raw['mode'].toString(), Colors.blueGrey), const Spacer(), if ((raw['findings'] as List).isNotEmpty) badge('${(raw['findings'] as List).length} anomalie(s)', alertRed)]),
        const SizedBox(height: 10),
        Text(raw['agent'].toString(), style: const TextStyle(color: darkBlue, fontSize: 17, fontWeight: FontWeight.w800)),
        Text(prettyDate(raw['completedAt']?.toString()), style: const TextStyle(color: Colors.blueGrey, fontSize: 12)),
        const SizedBox(height: 7),
        Text('Non vérifiés : ${raw['missingCount']} • Nouveaux signalements : ${raw['newIssues']}', style: const TextStyle(color: Colors.blueGrey, fontSize: 12)),
        if ((raw['findings'] as List).isNotEmpty) Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: () async {
          try { await ERTStore.instance.shareReport(Map<String, dynamic>.from(raw as Map)); }
          catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PDF impossible : $e'))); }
        }, icon: const Icon(Icons.picture_as_pdf), label: const Text('Rapport PDF'))),
      ]))),
    ]);
  }
}

class ScannerPage extends StatefulWidget {
  const ScannerPage({super.key});
  @override
  State<ScannerPage> createState() => _ScannerPageState();
}
class _ScannerPageState extends State<ScannerPage> {
  bool found = false;
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Scanner un QR véhicule')),
    body: Column(children: [
      Expanded(child: MobileScanner(onDetect: (capture) {
        if (found) return;
        for (final code in capture.barcodes) {
          final raw = code.rawValue?.trim() ?? '';
          if (!raw.startsWith('ERTINV:')) continue;
          final vehicle = raw.substring('ERTINV:'.length).toUpperCase().trim();
          if (ERTStore.instance.vehicles.any((v) => v['id'] == vehicle)) {
            found = true;
            Navigator.pop(context, vehicle);
            break;
          }
        }
      })),
      const Padding(padding: EdgeInsets.all(16), child: Text('Scannez le QR code ERTINV: suivi du nom du véhicule pour ouvrir son inventaire.', textAlign: TextAlign.center)),
    ]));
}

class AdminGatePage extends StatefulWidget {
  const AdminGatePage({super.key});
  @override
  State<AdminGatePage> createState() => _AdminGatePageState();
}
class _AdminGatePageState extends State<AdminGatePage> {
  bool granted = false;
  final field = TextEditingController();
  final store = ERTStore.instance;
  bool hasError = false;
  @override
  void dispose() {field.dispose(); super.dispose();}
  @override
  Widget build(BuildContext context) {
    if (granted) return AdminPanel(onExit: () => setState(() {granted = false; field.clear();}));
    final first = !store.adminConfigured;
    return ListView(padding: const EdgeInsets.all(25), children: [
      const SizedBox(height: 23),
      const Icon(Icons.admin_panel_settings_outlined, size: 60, color: darkBlue),
      const SizedBox(height: 15),
      Center(child: Text(first ? 'Créer le code de démonstration' : 'Accès administrateur', style: const TextStyle(fontSize: 22, color: darkBlue, fontWeight: FontWeight.w800), textAlign: TextAlign.center)),
      const SizedBox(height: 13),
      Text(first ? 'Pour cette version locale, définissez un code à 4 chiffres minimum. Il sera propre à ce téléphone.' : 'Saisissez le code administrateur local.', textAlign: TextAlign.center),
      const SizedBox(height: 20),
      TextField(controller: field, obscureText: true, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: first ? 'Nouveau code' : 'Code administrateur', errorText: hasError ? 'Code incorrect ou trop court.' : null)),
      const SizedBox(height: 14),
      FilledButton(onPressed: () async {
        if (first && field.text.length >= 4) {await store.setAdminPin(field.text); setState(() {granted = true; hasError = false;});}
        else if (!first && store.verifyAdminPin(field.text)) {setState(() {granted = true; hasError = false;});}
        else {setState(() => hasError = true);}
      }, child: Text(first ? 'CRÉER ET ACCÉDER' : 'DÉVERROUILLER')),
      const SizedBox(height: 22),
      const Text('⚠️ Protection de démonstration. Un simple code conservé localement ne sécurise pas les droits des 27 agents : il faudra une authentification et des permissions côté serveur avant un déploiement réel.', style: TextStyle(fontSize: 12, color: Colors.blueGrey)),
    ]);
  }
}

class AdminPanel extends StatefulWidget {
  final VoidCallback onExit;
  const AdminPanel({required this.onExit, super.key});
  @override
  State<AdminPanel> createState() => _AdminPanelState();
}
class _AdminPanelState extends State<AdminPanel> {
  final store = ERTStore.instance;
  Future<void> changeIssue(Map<String, dynamic> issue) async {
    final status = await showDialog<String>(context: context, builder: (ctx) => SimpleDialog(title: Text(issue['title'].toString()), children: [
      SimpleDialogOption(onPressed: () => Navigator.pop(ctx, 'open'), child: const Text('🔴 Ouverte')),
      SimpleDialogOption(onPressed: () => Navigator.pop(ctx, 'in_progress'), child: const Text('🟠 En cours')),
      SimpleDialogOption(onPressed: () => Navigator.pop(ctx, 'resolved'), child: const Text('🟢 Résolue')),
    ]));
    if (status == null) return;
    await store.issueStatus(issue['id'].toString(), status);
    if (mounted) setState(() {});
  }

  Future<void> editCatalog(Map<String, dynamic> section, [Map<String, dynamic>? item]) async {
    final label = TextEditingController(text: item?['label']?.toString() ?? '');
    final qty = TextEditingController(text: item?['quantity']?.toString() ?? '');
    final result = await showDialog<Map<String, dynamic>>(context: context, builder: (ctx) => AlertDialog(
      title: Text(item == null ? 'Ajouter un équipement' : 'Modifier un équipement'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: label, decoration: const InputDecoration(labelText: 'Nom et description')),
        const SizedBox(height: 12),
        TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantité attendue (facultatif)')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
        FilledButton(onPressed: () {
          if (label.text.trim().isEmpty) return;
          final n = qty.text.trim().isEmpty ? null : int.tryParse(qty.text.trim());
          if (qty.text.trim().isNotEmpty && (n == null || n < 0)) return;
          Navigator.pop(ctx, {'label':label.text.trim(),'quantity':n});
        }, child: const Text('Enregistrer'))],
    ));
    label.dispose(); qty.dispose();
    if (result == null) return;
    final sectionIndex = store.sections.indexWhere((s) => s['id'] == section['id']);
    if (sectionIndex < 0) return;
    final updated = Map<String, dynamic>.from(store.sections[sectionIndex] as Map);
    final items = List<dynamic>.from(updated['items'] as List);
    if (item == null) {items.add({'id':'${section['id']}_${newId()}','active':true,...result});}
    else {
      final idx = items.indexWhere((it) => it['id'] == item['id']);
      if (idx >= 0) items[idx] = {...Map<String, dynamic>.from(items[idx] as Map),...result};
    }
    updated['items'] = items;
    final all = store.sections;
    all[sectionIndex] = updated;
    store.updateCurrentSections(all);
    await store.persistCatalog();
    if (mounted) setState(() {});
  }

  Future<void> disableItem(Map<String, dynamic> section, Map<String, dynamic> item) async {
    final idx = store.sections.indexWhere((s) => s['id'] == section['id']);
    if (idx < 0) return;
    final all = store.sections;
    final current = Map<String, dynamic>.from(all[idx] as Map);
    final items = List<dynamic>.from(current['items'] as List);
    final itidx = items.indexWhere((e) => e['id'] == item['id']);
    if (itidx < 0) return;
    items[itidx] = {...Map<String, dynamic>.from(items[itidx] as Map),'active': false};
    current['items'] = items;
    all[idx] = current;
    store.updateCurrentSections(all);
    await store.persistCatalog();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final open = store.issues.where((e) => e['status'] != 'resolved').toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [const Expanded(child: Text('Administration locale', style: TextStyle(fontSize: 20, color: darkBlue, fontWeight: FontWeight.w800))), TextButton(onPressed: widget.onExit, child: const Text('Verrouiller'))]),
      const Text('Modifications propres à ce téléphone. Version de démonstration.', style: TextStyle(fontSize: 12, color: Colors.blueGrey)),
      const SizedBox(height: 20),
      const Text('ANOMALIES EN COURS', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: darkBlue)),
      const SizedBox(height: 8),
      if (open.isEmpty) padCard(child: const Text('Aucune anomalie ouverte.')),
      for (final raw in open) Padding(padding: const EdgeInsets.only(bottom: 7), child: padCard(child: ListTile(contentPadding: EdgeInsets.zero,
        title: Text(raw['title'].toString()), subtitle: Text('${raw['vehicle']} • ${raw['status']}'), trailing: const Icon(Icons.edit_note), onTap: () => changeIssue(Map<String, dynamic>.from(raw as Map))))),
      const SizedBox(height: 18),
      const Text('CATALOGUE DU VÉHICULE', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: darkBlue)),
      const SizedBox(height: 8),
      ...store.sections.map((raw) {
        final s = Map<String, dynamic>.from(raw as Map);
        final items = List<dynamic>.from(s['items'] as List).where((e) => e['active'] != false).toList();
        return Padding(padding: const EdgeInsets.only(bottom: 8), child: Card(child: ExpansionTile(title: Text(s['title'].toString()), subtitle: Text('${items.length} équipements'), children: [
          for (final r in items) ListTile(dense: true, title: Text(r['label'].toString(), style: const TextStyle(fontSize: 12)),
            onTap: () => editCatalog(s, Map<String, dynamic>.from(r as Map)),
            trailing: IconButton(onPressed: () => disableItem(s, Map<String, dynamic>.from(r as Map)), tooltip: 'Retirer des prochains inventaires', icon: const Icon(Icons.remove_circle_outline, color: alertRed))),
          TextButton.icon(onPressed: () => editCatalog(s), icon: const Icon(Icons.add), label: const Text('Ajouter un équipement')),
          const SizedBox(height: 7),
        ])));
      }),
      const SizedBox(height: 10),
      const Text('Les équipements retirés sont désactivés dans les nouveaux contrôles sans effacer les historiques.', style: TextStyle(color: Colors.blueGrey, fontSize: 11)),
    ]);
  }
}
